<?php
require_once(__DIR__ . "/../../util/config.php");
?>

<nav class="navbar navbar-expand-md bg-secondary px-3">
    <img class="navbar-brand"
    src="img/polystation2.png" 
    style="max-width: 7%; height: 7%;">
    <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">Sistema de Jogos</a>

    <button class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navSite">
    
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                    id="navDropDown" data-bs-toggle="dropdown">Cadastros</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/view/jogos/listar.php">
                        Jogos</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Sobre</a>
            </li>
        </ul>
        
    </div>
</nav>
