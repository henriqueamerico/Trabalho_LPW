<?php

//Mostra erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "db_jogos");
define("DB_USER", "root");
define("DB_PASSWORD", "");

//Configuração do ambiente
define("AMB_DEV", true);

//Configuração de acesso (TEM Q CUIDAR COM ISSO)
define("BASE_URL", "/LPW-main/crud_jogos1/crud_jogos1");
