<?php
require_once(__DIR__ . "/util/config.php");

require_once(__DIR__ . "/view/include/header.php");
require_once(__DIR__ . "/view/include/menu.php");
?>


<div class="row mt-3 justify-content-center">
    <div class="col-5">
        
           

            <div class="card-body">
                
            </div>

            <ul class="list-group list-group-flush">
                <li class="list-group-item">
                    
                </li>
            </ul>
        </div>
    </div>
</div>


<?php
require_once(__DIR__ . "/view/include/footer.php");
?>
